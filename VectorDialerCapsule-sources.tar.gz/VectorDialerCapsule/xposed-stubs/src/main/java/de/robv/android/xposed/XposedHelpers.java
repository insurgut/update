package de.robv.android.xposed;
public final class XposedHelpers { public static Object findAndHookMethod(Class<?> clazz, String name, Object... parametersAndCallback) { return null; } }
