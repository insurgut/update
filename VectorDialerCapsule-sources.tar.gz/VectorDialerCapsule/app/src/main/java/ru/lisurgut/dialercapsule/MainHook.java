package ru.lisurgut.dialercapsule;

import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/** Vector / legacy-Xposed runtime module. Does not touch call recording notifications. */
public final class MainHook implements IXposedHookLoadPackage {
    private static final String TARGET = "com.google.android.dialer";
    private static final WeakHashMap<Activity, Controller> controllers = new WeakHashMap<>();

    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET.equals(lpparam.packageName)) return;
        XposedBridge.log("DialerCapsule: attached to " + lpparam.packageName);
        XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam param) {
                final Activity activity = (Activity) param.thisObject;
                activity.runOnUiThread(() -> {
                    if (activity.getWindow() == null) return;
                    Controller controller = controllers.get(activity);
                    if (controller == null) {
                        controller = new Controller(activity);
                        controllers.put(activity, controller);
                    }
                    controller.start();
                });
            }
        });
    }

    static final class Target {
        final View view;
        final AccessibilityNodeProvider provider;
        final int virtualId;
        final Rect bounds;
        final String label;
        final int priority;
        Target(View v, AccessibilityNodeProvider p, int id, Rect r, String s, int priority) {
            this.view = v; this.provider = p; this.virtualId = id;
            this.bounds = r; this.label = s; this.priority = priority;
        }
        boolean press() {
            try {
                if (provider != null) return provider.performAction(virtualId, AccessibilityNodeInfo.ACTION_CLICK, null);
                return view != null && view.performClick();
            } catch (Throwable t) { XposedBridge.log("DialerCapsule click: " + t); return false; }
        }
    }

    static final class Controller implements Runnable {
        final Activity activity;
        final FrameLayout root;
        final FrameLayout overlay;
        final ImageView hangup;
        final ImageView microphone;
        Target endTarget, muteTarget;
        View previousHiddenMute;
        boolean working;
        boolean muted;
        int lastX = Integer.MIN_VALUE, lastY = Integer.MIN_VALUE;
        int lastEnd, lastMute;
        int emptyCycles;

        Controller(Activity activity) {
            this.activity = activity;
            this.root = (FrameLayout) activity.getWindow().getDecorView();
            overlay = new FrameLayout(activity);
            overlay.setTag("ru.lisurgut.dialercapsule.overlay");
            overlay.setVisibility(View.GONE);
            overlay.setClipChildren(false);
            overlay.setClipToPadding(false);
            hangup = new ImageView(activity);
            microphone = new ImageView(activity);
            hangup.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            microphone.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            hangup.setPadding(dp(21), dp(19), dp(21), dp(19));
            microphone.setPadding(dp(19), dp(19), dp(19), dp(19));
            int leftW = dp(72), rightW = dp(62), gap = dp(4), height = dp(64);
            FrameLayout.LayoutParams a = new FrameLayout.LayoutParams(leftW, height);
            FrameLayout.LayoutParams b = new FrameLayout.LayoutParams(rightW, height);
            b.leftMargin = leftW + gap;
            overlay.addView(hangup, a);
            overlay.addView(microphone, b);
            hangup.setContentDescription("Завершить звонок");
            microphone.setContentDescription("Микрофон");
            hangup.setOnClickListener(v -> { if (endTarget != null) endTarget.press(); });
            microphone.setOnClickListener(v -> { if (muteTarget != null) muteTarget.press(); });
            overlay.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
            root.addView(overlay, new FrameLayout.LayoutParams(leftW + gap + rightW, height));
            paint(false);
        }
        int dp(float value) { return (int) (activity.getResources().getDisplayMetrics().density * value + .5f); }
        void start() {
            if (working) return;
            working = true;
            root.postDelayed(this, 300);
        }
        @Override public void run() {
            if (!working || activity.isFinishing() || activity.isDestroyed()) { stop(); return; }
            try {
                if (!activity.hasWindowFocus()) {
                    overlay.setVisibility(View.GONE);
                } else {
                    update();
                }
            } catch (Throwable error) {
                overlay.setVisibility(View.GONE);
                if (emptyCycles++ < 2) XposedBridge.log("DialerCapsule update: " + error);
            }
            root.postDelayed(this, 650);
        }
        void stop() {
            working = false;
            overlay.setVisibility(View.GONE);
            restore();
            root.removeCallbacks(this);
        }
        void restore() {
            if (previousHiddenMute != null) {
                previousHiddenMute.setAlpha(1f);
                previousHiddenMute = null;
            }
        }
        void update() {
            List<Target> ends = new ArrayList<>(), mutes = new ArrayList<>();
            inspectView(root, ends, mutes, 0);
            endTarget = choose(ends);
            muteTarget = choose(mutes);
            if (endTarget == null || muteTarget == null || endTarget == muteTarget) {
                overlay.setVisibility(View.GONE);
                restore();
                return;
            }
            int[] loc = new int[2];
            root.getLocationOnScreen(loc);
            Rect r = endTarget.bounds;
            if (r.isEmpty() || r.centerY() < root.getHeight() / 3) {
                overlay.setVisibility(View.GONE);
                restore();
                return;
            }
            int w = dp(138), h = dp(64);
            int x = Math.min(Math.max(0, r.centerX() - loc[0] - dp(36)), Math.max(0, root.getWidth() - w - dp(8)));
            int y = Math.max(0, Math.min(r.centerY() - loc[1] - h / 2, root.getHeight() - h));
            if (x != lastX || y != lastY) {
                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) overlay.getLayoutParams();
                lp.leftMargin = x; lp.topMargin = y;
                overlay.setLayoutParams(lp);
                lastX = x; lastY = y;
            }
            boolean isMuted = isUnmute(muteTarget.label);
            if (overlay.getVisibility() != View.VISIBLE || muted != isMuted) {
                muted = isMuted;
                paint(muted);
            }
            if (muteTarget.view != null && muteTarget.view != previousHiddenMute && muteTarget.view != microphone) {
                restore();
                previousHiddenMute = muteTarget.view;
                previousHiddenMute.setAlpha(0f);
            }
            overlay.setVisibility(View.VISIBLE);
            overlay.bringToFront();
            emptyCycles = 0;
        }
        void paint(boolean isMuted) {
            boolean dark = (activity.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                    == Configuration.UI_MODE_NIGHT_YES;
            int lightIcon = dark ? Color.WHITE : 0xff202126;
            hangup.setBackground(bg(0xffd93025, new float[]{dp(34), dp(34), dp(8), dp(8), dp(8), dp(8), dp(34), dp(34)}));
            microphone.setBackground(bg(dark ? 0xff36383d : 0xffdfe1e7,
                    new float[]{dp(8), dp(8), dp(34), dp(34), dp(34), dp(34), dp(8), dp(8)}));
            hangup.setImageDrawable(icon("comms_gm_ic_call_end_vd_theme_24", "gs_call_end_vd_theme_24", "incall_end_call_icon"));
            microphone.setImageDrawable(icon(isMuted ? "gs_mic_off_vd_theme_24" : "gs_mic_vd_theme_24",
                    isMuted ? "gm_filled_mic_off_vd_theme_24" : "quantum_gm_ic_mic_vd_theme_24", null));
            hangup.setColorFilter(Color.WHITE);
            microphone.setColorFilter(lightIcon);
            microphone.setContentDescription(isMuted ? "Включить микрофон" : "Выключить микрофон");
        }
        GradientDrawable bg(int color, float[] radii) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(color); g.setCornerRadii(radii);
            return g;
        }
        android.graphics.drawable.Drawable icon(String first, String second, String third) {
            String[] candidates = new String[]{first, second, third};
            for (String n : candidates) {
                if (n == null) continue;
                try {
                    int id = activity.getResources().getIdentifier(n, "drawable", TARGET);
                    if (id != 0) return activity.getDrawable(id);
                } catch (Throwable ignored) {}
            }
            return null;
        }
        void inspectView(View view, List<Target> ends, List<Target> mutes, int depth) {
            if (depth > 55 || view == overlay || !view.isShown()) return;
            int[] screen = new int[2];
            view.getLocationOnScreen(screen);
            Rect r = new Rect(screen[0], screen[1], screen[0] + view.getWidth(), screen[1] + view.getHeight());
            if (r.width() > 0 && r.height() > 0 && view.isClickable()) {
                String name = "";
                try { name = activity.getResources().getResourceEntryName(view.getId()); } catch (Throwable ignored) {}
                String desc = norm(view.getContentDescription());
                if (view instanceof android.widget.TextView) {
                    desc += " " + norm(((android.widget.TextView) view).getText());
                }
                boolean endById = containsAny(name, "incall_end_call", "end_call_button", "btn_end_call", "bubble_button_end_call");
                boolean muteById = containsAny(name, "btn_mute", "bubble_button_mute", "menu_mute");
                if (endById || isEnd(desc)) ends.add(new Target(view, null, -1, r, desc, endById ? 4 : 2));
                if (muteById || isMute(desc)) mutes.add(new Target(view, null, -1, r, desc, muteById ? 4 : 2));
            }
            // Compose exposes virtual accessibility buttons rather than actual android.widget.Button views.
            if (view.getClass().getName().contains("compose")) inspectProvider(view, ends, mutes);
            if (view instanceof ViewGroup) {
                ViewGroup vg = (ViewGroup) view;
                for (int i = 0; i < vg.getChildCount(); i++) inspectView(vg.getChildAt(i), ends, mutes, depth + 1);
            }
        }
        void inspectProvider(View host, List<Target> ends, List<Target> mutes) {
            try {
                AccessibilityNodeProvider p = host.getAccessibilityNodeProvider();
                if (p == null) return;
                List<Integer> visited = new ArrayList<>();
                inspectNode(p, -1, ends, mutes, visited, 0);
            } catch (Throwable ignored) {}
        }
        void inspectNode(AccessibilityNodeProvider p, int id, List<Target> ends, List<Target> mutes,
                         List<Integer> visited, int depth) {
            if (depth > 20 || visited.size() > 150 || visited.contains(id)) return;
            visited.add(id);
            AccessibilityNodeInfo node;
            try { node = p.createAccessibilityNodeInfo(id); } catch (Throwable t) { return; }
            if (node == null) return;
            String desc = norm(node.getContentDescription()) + " " + norm(node.getText());
            if (node.isClickable() || node.getActionList().contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK)) {
                Rect rect = new Rect();
                node.getBoundsInScreen(rect);
                if (!rect.isEmpty()) {
                    if (isEnd(desc)) ends.add(new Target(null, p, id, rect, desc, 3));
                    if (isMute(desc)) mutes.add(new Target(null, p, id, rect, desc, 3));
                }
            }
            try {
                Method getChildId = AccessibilityNodeInfo.class.getDeclaredMethod("getChildId", int.class);
                getChildId.setAccessible(true);
                for (int i = 0; i < Math.min(50, node.getChildCount()); i++) {
                    long child = (Long) getChildId.invoke(node, i);
                    inspectNode(p, (int) child, ends, mutes, visited, depth + 1);
                }
            } catch (Throwable ignored) {
                // Hidden API restrictions: no unsafe guessing when virtual button IDs are inaccessible.
            }
            node.recycle();
        }
        Target choose(List<Target> list) {
            Target best = null;
            for (Target t : list) {
                int score = t.priority * 10000 + t.bounds.centerY();
                if (best == null || score > best.priority * 10000 + best.bounds.centerY()) best = t;
            }
            return best;
        }
        static String norm(CharSequence s) { return s == null ? "" : s.toString().toLowerCase(Locale.ROOT); }
        static boolean containsAny(String s, String... options) { for (String o : options) if (s.contains(o)) return true; return false; }
        static boolean isEnd(String s) {
            return containsAny(s, "end call", "hang up", "завершить звонок", "завершить вызов", "сбросить звонок", "отклонить вызов");
        }
        static boolean isMute(String s) {
            return containsAny(s, "mute", "unmute", "микрофон", "отключить звук", "выключить звук");
        }
        static boolean isUnmute(String s) {
            return containsAny(s, "unmute", "включить микрофон", "включить звук");
        }
    }
}
