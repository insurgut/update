# Dialer Capsule for Vector (experimental)

Xposed module, designed for Google Phone v244 (com.google.android.dialer).

- Hooks Android Activity.onResume in the dialer process.
- Looks up the hangup and mute controls in regular Android views and Compose virtual accessibility nodes.
- Adds a two-button capsule anchored at the original hangup button, with the mic on the right.
- Does not silence call recording notifications, or bypass regional recording restrictions. On supported phones, use Google Phone > Settings > Call recording > Play audio tone instead of disclaimer.

## Limitations

Not tested on a device. Android 17 hidden-API restrictions may prevent Compose virtual nodes from being traversed. In that case the module leaves the UI unchanged rather than intercepting wrong buttons. If a Compose virtual mute control is found, the original button can remain visible; view-based mute controls are hidden with alpha only while overlay is active. Enable module for com.google.android.dialer in Vector and force-stop/restart Google Phone.

## Build

Install JDK 17 and Android SDK 35, then `gradle :app:assembleDebug`. This project includes compile-only Xposed API stubs; they are never packaged into the APK.
